#ifndef SUN_H
#define SUN_H

#include "color.h"

#define sun_width  8
#define sun_height 8
extern color_t sun_data[sun_width * sun_height];

#endif // SUN_H
