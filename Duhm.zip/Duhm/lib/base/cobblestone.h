#ifndef COBBLESTONE_H
#define COBBLESTONE_H

#include "color.h"

#define cobblestone_width  16
#define cobblestone_height 16
extern color_t cobblestone_data[cobblestone_width * cobblestone_height];

#endif // COBBLESTONE_H
