#ifndef BALL_H
#define BALL_H

#include "color.h"

#define ball_width  8
#define ball_height 8
extern color_t ball_data[ball_width * ball_height];

#endif // BALL_H
