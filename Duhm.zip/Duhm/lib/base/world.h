#ifndef WORLD_H
#define WORLD_H

#include <stdint.h>

#define world_width 8
#define world_height 8
extern uint8_t world_data[world_width * world_height];

#endif // WORLD_H
