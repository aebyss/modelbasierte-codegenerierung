#ifndef SHADOW_H
#define SHADOW_H

#include "stdint.h"

#define shadow_width  8
#define shadow_height 8
extern uint8_t shadow_data[shadow_width * shadow_height];

#endif // SHADOW_H
