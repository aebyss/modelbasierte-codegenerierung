#ifndef DIRT_H
#define DIRT_H

#include "color.h"

#define dirt_width  16
#define dirt_height 16
extern color_t dirt_data[dirt_width * dirt_height];

#endif // DIRT_H
